<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBasicPostModelsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('basic_post_models', function (Blueprint $table) {
            $table->id();

            $table->foreignId('category_id')->nullable(); 
            $table->foreignId('user_id')->nullable(); 

            $table->string("judul");
            $table->string("slug")->unique(); 

            $table->string('preview'); 
            $table->string('preview_id')->nullable();

            $table->text('deskripsi');
            $table->text('skripsi');
            
            $table->timestamp('published')->nullable(); 
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('basic_post_models');
    }
}
