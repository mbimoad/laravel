<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\BasicPostModel;
use App\Models\BasicCategoryModel;


class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        User::factory(3)->create();
        BasicPostModel::factory(5)->create(); 
        BasicCategoryModel::create(["nama" => "logika fuzzy", "tipe" => "desktop"]);
        BasicCategoryModel::create(["nama" => "c45", "tipe" => "website"]);
    }
}
