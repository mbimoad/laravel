$('#summernote').summernote({
    placeholder: 'Hello bootstrap 4',
    tabsize: 2,
    height: 100
});


fetch(`/checktoken`)
.then(response => response.json())
.then(response => {
    console.log(response);
    if(response.message == "Token expired") {
        alert("Token has been expired");
    }
});
