
<?php $__env->startSection('contents'); ?>
    <h1>Dashboard</h1>

    <div>
        <canvas id="myChart"></canvas>
      </div>
      
      <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
      
      <script>
        var dataFromLaravel = <?php echo json_encode($data); ?>;
        const ctx = document.getElementById('myChart');

        let vlabels = dataFromLaravel.map(item => item.category_relation.nama); 
        let vcounts = dataFromLaravel.map(item => item.QTY); 


        new Chart(ctx, {
          type: 'bar',
          data: {
            labels: vlabels,
            datasets: [{
              label: '# of Votes',
              data: vcounts,
              borderWidth: 1
            }]
          },
          options: {
            scales: {
              y: {
                beginAtZero: true
              }
            }
          }
        });
      </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Second Brain\Laravel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>