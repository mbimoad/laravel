
<?php $__env->startSection('contents'); ?>
    
    <div class="box">
        
        <?php if(isset($datas1) && count($datas1) != 0): ?> 
        <ul class="list">
            
            <?php $__currentLoopData = $datas1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="/base/<?php echo e($data1["nama"]); ?>"><?php echo e($data1["nama"]); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
        
        <?php if(isset($datas2)): ?> 
            <h1><?php echo e($datas2["nama"]); ?></h1>
            <h3><?php echo e($datas2["jurusan"]); ?></h3>
        <?php elseif(!isset($datas2)): ?>
            <span>Click To Show The Detail</span>
        <?php else: ?> 
            <span>Data Empty</span>
        <?php endif; ?> 
    </div>


    <div class="box">
        <?php if(isset($datas3)): ?>
        <?php $__currentLoopData = $datas3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <a href="post/<?php echo e($d->slug); ?>" class="card">
                <h3><?php echo e($d->judul); ?></h3>
                <p><?php echo \Illuminate\Support\Str::limit($d->skripsi, 60, '....'); ?></p>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Second Brain\Laravel\resources\views/pages/basic.blade.php ENDPATH**/ ?>