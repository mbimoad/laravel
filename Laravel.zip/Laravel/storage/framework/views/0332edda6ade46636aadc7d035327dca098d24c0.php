
<?php $__env->startSection('contents'); ?>
    <h3>How Much View this Page <?php echo e($views); ?></h3>
    <span><?php echo e($post->usersRelation->name); ?></span>
    <h1><?php echo e($post->judul); ?></h1>
    <p><?php echo $post->skripsi; ?></p>
    <span class="value"><?php echo e(\Carbon\Carbon::parse($post->updated_at)->format('F, j Y')); ?></span>
    <a href="/admin/laravel">Kembali</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Second Brain\Laravel\resources\views/admin/detail.blade.php ENDPATH**/ ?>