
<?php $__env->startSection('contents'); ?>




<label for="">Current Token</label>
<input type="text" name="" value="<?php echo e($currtoken); ?>">

<button class="googlebtn id btn btn-primary" type="button">Copy Oauth Client ID</button>  
<button class="googlebtn secret btn btn-primary" type="button">Copy Oauth Client Secret</button>  


<form action="/setrefreshtoken" method="POST" class="d-flex">
    <?php echo csrf_field(); ?> 
    <input type="text" class="form-control" name="refreshtoken" placeholder="New Refresh Token">
    <button type="submit" class="sbmt ml-2 btn btn-info">Send</button>
</form>

<?php if(session()->has('success')): ?>
    <?php echo e(session('success')); ?>

<?php endif; ?>



<script>
     const id = document.querySelector('.googlebtn.id'); 
    const secret = document.querySelector('.googlebtn.secret'); 
    
     id.addEventListener('click', function() {
        navigator.clipboard.writeText('400060317614-kbh3o66a5qgadhfnm6l8nq2pqb2mabsl.apps.googleusercontent.com'); 
        alert('Oauth Client ID is Copied');
    })

    secret.addEventListener('click', function() {
        navigator.clipboard.writeText('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'); 
        alert('Oauth Client Secret is Copied');
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Second Brain\Laravel\resources\views/admin/refreshtoken.blade.php ENDPATH**/ ?>