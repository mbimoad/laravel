
<?php $__env->startSection('contents'); ?>
    <div class="form">
        <input type="text" class="csrf" readonly value="<?php echo e(csrf_token()); ?>">
        <input type="text" class="cname" placeholder="nama">
        <input type="text" class="ctipe" placeholder="tipe">
        <input type="file" class="cicon">
        <button onclick="sendData(`/category/store`)" type="button">Kirim</button>

    </div>

    <script>
        const formdata = new FormData();
        const name = document.querySelector('.cname');
        const tipe = document.querySelector('.ctipe');
        const icon = document.querySelector('.cicon');
        const csrf    = document.querySelector('.csrf'); 
        const options = {
            method: 'POST', 
            body: formdata, 
            headers: {"X-CSRF-Token": csrf.value},
            credentials: "same-origin",
        }
        

        function sendData(url) {
            formdata.append("nama", name.value); 
            formdata.append("tipe", tipe.value); 
            formdata.append("icon", icon.files[0]); 
            fetch(url, options)
                .then(response => response.json())
                .then(response => {
                    let status = response.status; 
                    if(status == "OK") {
                        alert(status);
                    } else {
                        alert(status);
                    }
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Second Brain\Laravel\resources\views/category/create.blade.php ENDPATH**/ ?>