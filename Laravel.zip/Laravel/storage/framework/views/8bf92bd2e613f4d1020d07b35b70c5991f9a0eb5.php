
<?php $__env->startSection('contents'); ?>
    <?php if(session()->has('failed')): ?>
        <span><?php echo e(session('failed')); ?></span>
    <?php endif; ?>

    <?php if(session()->has('success')): ?> 
        <span><?php echo e(session('success')); ?></span>
    <?php endif; ?>


    <?php if(strtolower($title) == "login"): ?>
        <a href="/register">Register</a>
    <?php elseif(strtolower($title) == "register"): ?>
        <a href="/login">Login</a>
    <?php endif; ?> 

    <form action="<?php echo e($formlink); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 

        <?php if(strtolower($title) == "register"): ?>
            <input type="text"      value="<?php echo e(@old('name')); ?>" name="name" placeholder="username">
        <?php endif; ?> 
        
        <input type="email"     value="<?php echo e(@old('email')); ?>" name="email" placeholder="email">
        <input type="password"  value="<?php echo e(@old('password')); ?>" name="password" placeholder="password">
        <button type="submit">Login</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Second Brain\Laravel\resources\views/pages/form.blade.php ENDPATH**/ ?>