
<?php $__env->startSection('contents'); ?>

    <div class="loader"></div>

    <form action="/admin/laravel/<?php echo e($post->slug); ?>" class="myform" method="POST" enctype="multipart/form-data">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        
        <input type="text" name="slug" value="<?php echo e($post->slug); ?>" readonly>
        
        <input type="text" name="judul" value="<?php echo e($post->judul); ?>" placeholder="judul">
        
        <select name="category_id" >
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($c->id == $post->category_id): ?>
                    <option selected value="<?php echo e($c->id); ?>"><?php echo e($c->nama); ?></option>
                <?php else: ?> 
                    <option value="<?php echo e($c->id); ?>"><?php echo e($c->nama); ?></option>
                <?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        
        <textarea placeholder="deskripsi" name="deskripsi"><?php echo e($post->deskripsi); ?></textarea>

        
        <input type="file" name="preview" class="preview" onchange="shareScreen()">
        <img src="https://drive.google.com/thumbnail?id=<?php echo e($post->preview_id); ?>" class="showimage">

        <textarea placeholder="skripsi" id="summernote" name="skripsi">
            <?php echo e($post->skripsi); ?>   
        </textarea>
        
        <button class="kirim" type="submit">Update (Laravel)</button>
    </form>

    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>        <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>       <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>   <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['preview'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['skripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <script>
        const image = document.querySelector('.preview');
        const imgPreview = document.querySelector('.showimage');
        function shareScreen() {
            const reader = new FileReader(); 
            reader.readAsDataURL(image.files[0]);
            reader.onload = function(e) {
                imgPreview.src = e.target.result;
            }
        }

        const judul = document.querySelector('input[name="judul"]');
        const slug = document.querySelector('input[name="slug"]');

        judul.addEventListener('change', function() {
            fetch('/checkslug?param=' + judul.value)
                .then(response => response.json())
                .then(response => slug.value = response.slug)
        })


        const loader = document.querySelector(".loader");
        const kirim = document.querySelectorAll('.kirim'); 
        kirim.forEach(item => item.addEventListener('click', function() {
            loader.classList.add('active');
        }))

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Second Brain\Laravel\resources\views/admin/update.blade.php ENDPATH**/ ?>