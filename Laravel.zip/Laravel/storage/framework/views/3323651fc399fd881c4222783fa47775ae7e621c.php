
<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script><?php /**PATH D:\Second Brain\Laravel\resources\views/partial/script.blade.php ENDPATH**/ ?>