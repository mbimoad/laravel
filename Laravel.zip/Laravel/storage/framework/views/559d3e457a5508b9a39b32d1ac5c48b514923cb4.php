
<?php $__env->startSection('contents'); ?>

    <?php if(isset($cate)): ?>
    <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="/cate/<?php echo e($c->id); ?>"><?php echo e($c->nama); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?> 


    <form action="/post">
        <input type="text" name="keyword">
        <input type="number" name="tahun">
        <button type="submit">Find</button>
    </form>
    

    <div class="box">
        <?php if(isset($datas3) && $datas3->count() > 0): ?>
        <?php $__currentLoopData = $datas3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        
            <a href="/post/<?php echo e($d->slug); ?>" class="card">
                <h3><?php echo e($d->judul); ?></h3>
                <span><?php echo e($d->usersRelation->name); ?></span>
                <span><?php echo e($d->categoryRelation->nama); ?></span>
                <p><?php echo \Illuminate\Support\Str::limit($d->skripsi, 60, '....'); ?></p>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>

    <?php if(isset($datas3)): ?>
    
    <div class="">
        <?php echo e($datas3->links()); ?>

    </div>
    <?php endif; ?> 

    
    <div class="detail">
        <?php if(isset($datas4)): ?> 
            <span class="value"><?php echo e(\Carbon\Carbon::parse($datas4->updated_at)->format('F, j Y')); ?></span>
            <h1><?php echo e($datas4->judul); ?></h1>
            <?php echo $datas4->skripsi; ?>

            <a href="/post">Kembali</a>
        <?php endif; ?>   
    </div>


    <div class="categorypost">
        <?php if(isset($datas5)): ?>
            <?php $__currentLoopData = $datas5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="value"><?php echo e(\Carbon\Carbon::parse($d->updated_at)->format('F, j Y')); ?></span>
                <h1><?php echo e($d->judul); ?></h1>
                <?php echo $d->skripsi; ?>

             
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="/post">Kembali</a>
        <?php endif; ?> 
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Second Brain\Laravel\resources\views/pages/posts.blade.php ENDPATH**/ ?>