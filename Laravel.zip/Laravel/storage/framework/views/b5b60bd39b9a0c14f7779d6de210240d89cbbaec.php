
<?php $__env->startSection('contents'); ?>
    
    <h1><?php echo e(Request::is('admin/laravel*') ? "Halaman Admin" : ""); ?></h1>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-warning" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <form action="/admin/laravel" method="GET">
        <input type="text" name="keyword" value="<?php echo e(old('keyword')); ?>">
        <select name="tahun">
            <option value="" selected>Year</option>
            <option value="2025">2025</option>
            <option value="2024">2024</option>
            <option value="2023">2023</option>
        </select>
        <button type="submit">Cari</button>
    </form>

    <a href="/admin/laravel/create">Tambah Posts</a> 
    <table border="1" cellspacing="0">
        <tr>
            <td>No</td>
            <td>Judul</td>
            <td>Cover</td>
            <td>Cover</td>
            <td>Category</td>
            <td>Action</td>
        </tr>
        

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <tr>
            
            <td><?php echo e($index + 1 + ($posts->currentPage() - 1) * $posts->perPage()); ?></td>
            <td><?php echo e(\Illuminate\Support\Str::limit($p->judul, 10, '....')); ?></td>
            <td><img src="https://drive.google.com/thumbnail?id=<?php echo e($p->preview_id); ?>&sz=w1000"></td>
            <td><img src="<?php echo e(asset('storage/upload/' . $p->preview)); ?>" alt="Example Image"></td>
            <td><?php echo e($p->categoryRelation->nama); ?></td>
            <td>
                <a href="/admin/laravel/<?php echo e($p->slug); ?>">Detail</a>
                <a href="/admin/laravel/<?php echo e($p->slug); ?>/edit">Update</a>
                <form action="/admin/laravel/<?php echo e($p->slug); ?>" method="POST">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?> 
                    <button type="submit">DELETE</button>
                </form>
            </td>


        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <div class="">
        <?php echo e($posts->links()); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Second Brain\Laravel\resources\views/admin/index.blade.php ENDPATH**/ ?>