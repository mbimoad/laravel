<header>
    
    <?php if(auth()->guard()->guest()): ?>
    <a href="/"     class="<?php echo e(strtolower($title)  == 'home' ? 'on' : ''); ?>">Home</a>
    <a href="/base" class="<?php echo e(strtolower($title)  == 'base' ? 'on' : ''); ?>">Get Data</a>
    <a href="/post" class="<?php echo e(strtolower($title)  == 'post' ? 'on' : ''); ?>">Post</a>
    <a href="/login" class="<?php echo e(strtolower($title) == 'login' ? 'on' : ''); ?>">Login</a>
    <?php endif; ?>


    
    <?php if(auth()->guard()->check()): ?>
    
    <form action="/logout" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit">logout</button>
    </form>

    <a href="/refreshtoken" class="<?php echo e(strtolower($title) == 'setup token' ? 'on' : ''); ?>">refreshtoken</a>
    
    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gate_admin')): ?>
        <a href="/admin/laravel" class="<?php echo e(strtolower($title) == 'add' ? 'on' : ''); ?>">POST CRUD</a>
    <?php endif; ?>
    
    <?php if(auth()->user()->name == "admin"): ?>
        <a href="/category" class="<?php echo e(strtolower($title) == 'category' ? 'on' : ''); ?>">KATEGORI SSR</a>
    <?php endif; ?>

    <?php endif; ?>
</header>

<?php /**PATH D:\Second Brain\Laravel\resources\views/partial/header.blade.php ENDPATH**/ ?>