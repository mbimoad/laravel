<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;


class BasicPostModel extends Model
{
    use HasFactory;
    use Sluggable; 

    // Pilih salah satu antara fillable / guarded 
    protected $fillable = ["judul", "slug", "skripsi", "preview", "deskripsi", "preview_id", "user_id", "category_id"]; 
    protected $guarded  = ["id"]; 
    public function categoryRelation() {
        return $this->belongsTo(BasicCategoryModel::class, 'category_id');
    }
    public function usersRelation() {
        return $this->belongsTo(User::class, 'user_id');
    }
    public function scopeCari($query, $values) {
        $query->when($values ?? false, function($myquery, $value) {
            return $myquery
                ->where('judul', 'like', '%' . $value['keyword'] . '%')
                ->where('created_at','like', '%' . $value['tahun'] . '%');
                // ->orWhere('category_id', $value['kategori']);
        });
    }

    public function getRouteKeyName() {
        return 'slug';
    }

    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'judul'
            ],
        ];
    }

}
