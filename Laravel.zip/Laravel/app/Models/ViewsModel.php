<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ViewsModel extends Model
{
    protected $guarded = ["id"]; 
    public function postmodel_relation() {
        return $this->belongsTo(BasicPostModel::class, "post_id"); 
    }
    use HasFactory;
}
