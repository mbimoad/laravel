<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BasicCategoryModel extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
    public function postRelation() {
        return $this->hasMany(BasicPostModel::class, 'id');
    }
    public function scopeCari($query, $keyword) {
        $query->when($keyword ?? false, function($myquery, $cari) {
            return $myquery
                ->where('nama', 'like', '%' . $cari . '%');
        });
    }
    
}
