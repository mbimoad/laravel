<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BasicModel extends Model
{
    use HasFactory;
    // Create Array
    private static $mhs = [
        ["nama" => "mbimoad", "jurusan" => "IT"],
        ["nama" => "syariel", "jurusan" => "IT"],
    ];
    // Converting the array into collection
    public static function GetData() {
        return collect(static::$mhs);
    } 
    // Find Data 
    public function findMhs($name) {
        $mhs = static::GetData(); 
        return $mhs->firstWhere('nama', $name);
    } 

}
