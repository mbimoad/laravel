<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BasicCategoryModel;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Storage;

class BasicCategoryController extends Controller
{
    public function autorisasiku() {
        if(auth()->guest()) abort(403); 
        if(auth()->user()->name != "admin") abort(403);
    }

    public function index() {
        $this->autorisasiku(); 

        $params  = ["title" => "Category"];
        return view('category.index', $params); 
    }

    public function create() {
        $params = ["title" => "Create Category"];
        return view('category.create', $params);
    }

    public function findData(Request $req) {
        $keyword = $req->keyword; 
        $params  = [
            "categories" => BasicCategoryModel::latest()
                                            ->Cari($keyword)
                                            ->paginate(2)
                                            ->withQueryString()
        ];
        return response()->json($params); 
    }

    public function stored(Request $request) {     
        // debug // return response()->json(["status" => "kesini"]);
        $data["nama"] = $request->nama; 
        $data["tipe"] = $request->tipe; 

        try {
            $this->saveIntoFileManager($request, $data);    
        } catch(QueryException $ex) {
            // echo "Error: " . $ex->getMessage();
            return response()->json(["status" => "FAILED"]);
        } 
        return response()->json(["status" => "OK"]);
    }

    public function update(BasicCategoryModel $param) {
        $params = [
            "title" => "Update", 
            "category" => $param, 
        ];
        return view('category.update', $params); 
    }

    public function edit(Request $request) {
        // debug // return response()->json(["status" => "kesini"]);
        $data["nama"] = $request->nama; 
        $data["tipe"] = $request->tipe; 

        try {
            $this->updateIntoFileManager($request, $data);    
        } catch(QueryException $ex) {
            // echo "Error: " . $ex->getMessage();
            return response()->json(["status" => "FAILED"]);
        } 
        return response()->json(["status" => "OK"]);
    }

    public function delete(BasicCategoryModel $param) {
        // debug // return response()->json(["status" => "kesini"]);
        if(Storage::disk('public')->exists('upload/' . $param->icon))  {
            Storage::disk('public')->delete('upload/' . $param->icon);
        }
        BasicCategoryModel::destroy($param->id); 
        return response()->json(["status" => "OK"]);
    }

    

    public function saveIntoFileManager($request, $data) {
        // echo $data["nama"];
        if($request->file('icon')) {
            $icon     = $request->file('icon'); 
            $iconName = $this->generateNewName($icon); 
            $icon->storeAs('upload', $iconName, 'public'); 
            $data["icon"] = $iconName; 
        }
        BasicCategoryModel::create($data); 
    }

    public function updateIntoFileManager($request, $data) {
        // echo $data["nama"];
        if($request->file('icon')) {
            $oldIcon  = $request->oldicon; 
            if(Storage::disk('public')->exists('upload/' . $oldIcon))  {
                Storage::disk('public')->delete('upload/' . $oldIcon);
            }
            $icon     = $request->file('icon'); 
            $iconName = $this->generateNewName($icon); 
            $icon->storeAs('upload', $iconName, 'public'); 
            $data["icon"] = $iconName; 
        }
        BasicCategoryModel::where('id', $request->id)->update($data);
    }


    public function generateNewName($file) {
        $format   = $file->getClientOriginalExtension();
        $name     = $file->getClientOriginalName();
        $name     = explode('.', $name)[0];
        $filename = $name . time() . '.' . $format; 
        return $filename; 
    }

    public function checkTokenExpired() {
        try {
            $files = Storage::disk('google')->listContents('');
        } catch(Exception $ex) {
            return Response()->json(['message' => 'Token expired']);
        }
        return Response()->json(['message' => 'Success']);
    }

}
