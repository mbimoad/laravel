<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BasicPostModel;
use App\Models\BasicCategoryModel;

class BasicPostController extends Controller
{
    public function index() {
        $values = request(['keyword', 'tahun', 'kategori']);
        $params = [
            "title"  => "Post", 
            "datas3" => BasicPostModel::with(['categoryRelation', 'usersRelation'])
                        ->latest()
                        ->Cari($values)
                        ->paginate(2)
                        ->withQueryString(),
            "cate"   => BasicCategoryModel::all(),
        ];
        return view('pages.posts', $params);
    }

    // Data Binding
    public function detail(BasicPostModel $param) {
        $params = [
            "title"  => "Detail", 
            "datas4" => $param
        ];
        return view('pages.posts', $params);
    }

    public function postcate(BasicCategoryModel $param) {
        $params = [
            "title"  => "Kategori Skripsi", 
            "datas5" => $param->postRelation->load(['usersRelation', 'categoryRelation'])
        ];
        return view('pages.posts', $params);
    }
}
