<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\BasicModel; 
use App\Models\BasicPostModel; 

class BasicController extends Controller
{
    // Basic
    public function index() {
        $params = [
            "datas1" => BasicModel::GetData(),
            "title" => "base",
        ]; 
        return view('pages.basic', $params); 
    }

    // Get Nama
    public function detail($vnama) {
        $params = [
            "datas2" => BasicModel::findMhs($vnama), 
            "title" => "detail"
        ];
        return view('pages.basic', $params); 
    }
}
