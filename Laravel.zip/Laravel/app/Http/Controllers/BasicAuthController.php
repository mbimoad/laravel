<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth; 
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class BasicAuthController extends Controller
{
    public function index() {
        $params = ["title" => "Login", "formlink" => "/auth"];
        return view('pages.form', $params);
    } 

    public function auths(Request $request) {
        $data = $request->validate(['email' => 'required|email', 'password' => 'required']);
        if(Auth::attempt($data)) {
            $request->session()->regenerate();
            return redirect()->intended('/dashboard'); // intended = supaya lewat middleware bawaan laravel (security)
        }
        return back()->with('failed', 'Login failed');
    }

    public function regist() {
        $params = ["title" => "Register", "formlink" => "/auth2"]; 
        return view('pages.form', $params);
    }

    public function auth2(Request $request) {
        $data = $request->validate([
            'name'  => 'required|min:3|max:255|unique:users', // SELECT * FROM users 
            'email' => 'required|email', 
            'password' => 'required',
        ]);

        $data["password"] = Hash::make($data["password"]); 
        User::create($data); 
        return redirect('/login')->with('success', 'Register success');
    }

    public function logout(Request $request) {
        Auth::logout(); 
        Request()->session()->invalidate(); 
        Request()->session()->regenerateToken(); 
        return redirect('/'); 
    }
}
