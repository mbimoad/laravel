<?php

namespace App\Http\Controllers;

use App\Models\ViewsModel;
use App\Http\Requests\StoreViewsModelRequest;
use App\Http\Requests\UpdateViewsModelRequest;

class ViewsModelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreViewsModelRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreViewsModelRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ViewsModel  $viewsModel
     * @return \Illuminate\Http\Response
     */
    public function show(ViewsModel $viewsModel)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ViewsModel  $viewsModel
     * @return \Illuminate\Http\Response
     */
    public function edit(ViewsModel $viewsModel)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateViewsModelRequest  $request
     * @param  \App\Models\ViewsModel  $viewsModel
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateViewsModelRequest $request, ViewsModel $viewsModel)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ViewsModel  $viewsModel
     * @return \Illuminate\Http\Response
     */
    public function destroy(ViewsModel $viewsModel)
    {
        //
    }
}
