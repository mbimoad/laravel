<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BasicPostModel;
use App\Models\BasicCategoryModel;

use DOMDocument;
use Illuminate\Support\Facades\File; 
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Artisan;
use Google\Service\Exception;


use \Cviebrock\EloquentSluggable\Services\SlugService;

class CrudPostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
   

    // PARSING DATA FROM LARAVEL INTO HTML
    public function dashboard() {
        $data = BasicPostModel::with(['categoryRelation'])->selectRaw("category_id, COUNT(*) AS QTY")->groupBy("category_id")->get(); 
        $params = [
            "title" => "Dashboard",
            "data" => $data, 
        ];
        return view('admin.dashboard', $params);
    }

    public function checkSlug(Request $request) {
        $slug = SlugService::createSlug(BasicPostModel::class, 'slug', $request->param);
        return Response()->json(['slug' => $slug]);
    } 

    public function index()
    {
        $values = request(['keyword', 'tahun', 'kategori']);
        
        if(auth()->user()->name == 'admin') {
            $posts =  BasicPostModel::with(['categoryRelation', 'usersRelation'])
                        ->latest()
                        ->Cari($values)
                        ->paginate(2)
                        ->withQueryString(); 
        } else {
            $posts =  BasicPostModel::with(['categoryRelation', 'usersRelation'])
                        ->where('user_id', auth()->user()->id)
                        ->latest()
                        ->Cari($values)
                        ->paginate(2)
                        ->withQueryString(); 
        }
        $params = [
            "title" => "Tambah", 
            "posts" => $posts, 
        ]; 

        return view('admin.index', $params);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $params = [
            "title" => "Create Post",
            "categories" => BasicCategoryModel::all(), 
        ];
        return view('admin.create', $params);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'judul'         => 'required', 
            'deskripsi'     => 'required',
            'slug'          => 'required',
            'skripsi'       => 'required',
            'category_id'   => 'required',
            'preview'       => 'required|mimes:jpg,jpeg,png|max:1024',
        ]);
        // don't forget to activate php artisan storage:link
        // registering "upload" into config/filesystem.php 
        // after registering. create folder upload in "storage/app/public/upload"
        // $this->saveIntoFileManager($request, $data);

            try {
                $this->saveIntoGoogleDrive($request, $data); 
            } catch(Exception $ex) {
                return redirect('/admin/laravel')->with('error', 'Token expired');
            }

        return redirect('/admin/laravel')->with('success', 'Adding Skripsi Success');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\BasicPostModel  $laravel
     * @return \Illuminate\Http\Response
     */
    public function show(BasicPostModel $laravel)
    {
        $params = [
            "title" => "Detail", 
            "post" => $laravel, 
        ];
        return view('admin.detail', $params);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\BasicPostModel  $laravel
     * @return \Illuminate\Http\Response
     */
    public function edit(BasicPostModel $laravel)
    {
        $params = [
            "title" => "Update", 
            "post" => $laravel,
            "categories" => BasicCategoryModel::all(), 
        ];
        return view('admin.update', $params); 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\BasicPostModel  $laravel
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, BasicPostModel $laravel)
    {
        $data = $request->validate([
            'judul'         => 'required', 
            'deskripsi'     => 'required',
            'slug'          => 'required',
            'skripsi'       => 'required',
            'category_id'   => 'required',
        ]);

        // $this->updateIntoFileManager($request, $data, $laravel); 
        
        try {
            $this->updateIntoGoogleDrive($request, $data, $laravel); 
        } catch(Exception $ex) {
            return redirect('/admin/laravel')->with('error', 'Token expired');
        }

        return redirect('/admin/laravel')->with('success', 'Update Skripsi Success');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\BasicPostModel  $laravel
     * @return \Illuminate\Http\Response
     */
    public function destroy(BasicPostModel $laravel)
    {
        // $this->deleteIntoFileManager($laravel); 

        try {
            $this->deleteIntoGoogleDrive($laravel); 
        } catch(Exception $ex) {
            return redirect('/admin/laravel')->with('error', 'Token expired');
        }
    
        return redirect('/admin/laravel')->with('success', 'Delete Skripsi Success');
    }
    public function generateNewName($file) {
        $format   = $file->getClientOriginalExtension();
        $name     = $file->getClientOriginalName();
        $name     = explode('.', $name)[0];
        $filename = $name . time() . '.' . $format; 
        return $filename; 
    }

    function getIdByFileName($filename) {
        $files  = Storage::disk('google')->files();
        $result = "";
        foreach($files as $file) {
            $file_id = Storage::disk ("google")->getMetaData($file);
            if($file_id["name"] == $filename) {
                $result = $file_id["path"]; 
                break;
            } 
        }
        return $result; 
    }
    public function DeleteGoogleImageIFLocalDeleted($request, $laravel) {
        // input user  
        $users_input = $request->skripsi;
        $dom = new DOMDocument(); 
        $dom->loadHTML($users_input, 9); 
        $users_image = $dom->getElementsByTagName("img"); 
        $users_image = collect($users_image);
        
        // database 
        $database_input = $laravel->skripsi;
        $dom1 = new DOMDocument(); 
        $dom1->loadHTML($database_input, 9); 
        $database_image = $dom1->getElementsByTagName("img"); 
        $database_image = collect($database_image);

        $srcdb = []; 
        $srcus = [];

       
        if(count($users_image) === 0 && count($database_image) != 0) {
            $result = $database_image;
            for($x=0; $x<count($result); $x++) $srcdb[] = $result[$x]->getAttribute('data-imgid'); 
            if(count($srcdb) != 0) {
               foreach($srcdb as $item) Storage::disk('google')->delete($item);
            }
        } else {
            
            for($x=0; $x<count($database_image); $x++) $srcdb[] = $database_image[$x]->getAttribute('data-imgid'); 
            for($x=0; $x<count($users_image); $x++) $srcus[]    = $users_image[$x]->getAttribute('data-imgid'); 
            $result = array_diff($srcdb, $srcus);
            if(count($result) != 0) {
               foreach($result as $item) Storage::disk('google')->delete($item);
            }
        }
    }

    public function DeleteFileManagerImageIFLocalDeleted($request, $laravel) {
        
        // input user  
        $users_input = $request->skripsi;
        $dom = new DOMDocument(); 
        $dom->loadHTML($users_input, 9); 
        $users_image = $dom->getElementsByTagName("img"); 
        $users_image = collect($users_image);
        
        // database 
        $database_input = $laravel->skripsi;
        $dom1 = new DOMDocument(); 
        $dom1->loadHTML($database_input, 9); 
        $database_image = $dom1->getElementsByTagName("img"); 
        $database_image = collect($database_image);

        $srcdb = []; 
        $srcus = [];


       
        if(count($users_image) === 0 && count($database_image) != 0) {
            $result = $database_image;
            for($x=0; $x<count($result); $x++) $srcdb[] = $result[$x]->getAttribute('data-imgid'); 
            if(count($srcdb) != 0) {
               foreach($srcdb as $item)  {
                    if(Storage::disk('public')->exists('upload/' . $item))  {
                        Storage::disk('public')->delete('upload/' . $item);
                    }
               }
               
            }
        } else {
            
            for($x=0; $x<count($database_image); $x++) $srcdb[] = $database_image[$x]->getAttribute('data-imgid'); 
            for($x=0; $x<count($users_image); $x++) $srcus[]    = $users_image[$x]->getAttribute('data-imgid'); 
            $result = array_diff($srcdb, $srcus);
            if(count($result) != 0) {
               foreach($result as $item) {
                    if(Storage::disk('public')->exists('upload/' . $item))  {
                        Storage::disk('public')->delete('upload/' . $item);
                    }
               }
            }
        }
    }

    public function updateIntoGoogleDrive($request, $data, $laravel) {
        $data["user_id"] = auth()->user()->id; 
        $data["preview"]     = $laravel->preview; 
        $data["preview_id"]  = $laravel->preview_id; 

        if($request->file('preview')) {
            // Delete old file 
            $oldpreview      = $laravel->preview_id; 
            Storage::disk('google')->delete($oldpreview);

            // Upload new file 
            $preview         = $this->generateNewName($request->file('preview')); 
            $data["preview"] = $preview; 
            $request->file('preview')->storeAs('', $preview, 'google');
            $data["preview_id"] = $this->getIdByFileName($preview);
            Storage::disk("google")->setVisibility($data["preview_id"], 'public');
        }


        $this->DeleteGoogleImageIFLocalDeleted($request, $laravel);
        $contents = $request->skripsi; 
        $dom = new DOMDocument(); 
        $dom->loadHTML($contents, 9); 
        $images = $dom->getElementsByTagName("img");  


         foreach($images as $key => $img) {
            //  kalo ada gambar baru 
            if(strpos($img->getAttribute('src'), 'data:image/') === 0) { 
                $imageData      = $img->getAttribute('src');
                $image          = base64_decode(explode(',', explode(';', $img->getAttribute('src'))[1])[1]);
                $extension      = explode('/', mime_content_type($imageData))[1]; 
                $image_name     = $key . time() . ".$extension"; 
                $image_path     = "/storage/upload/" . $image_name; 
                file_put_contents(public_path() . $image_path, $image);

                $imageContents = Storage::disk('upload')->get($image_name);
                $path = Storage::disk('google')->put($image_name, $imageContents);
                $image_id = $this->getIdByFileName($image_name); 
                Storage::disk("google")->setVisibility($image_id, 'public');
                $img->removeAttribute('src'); 
                $img->setAttribute('src', "https://drive.google.com/thumbnail?id=$image_id&sz=w1000");
                $img->setAttribute('data-imgid',$image_id);
                $img->setAttribute('class', 'custom');

                unlink("./storage/upload/" . $image_name);
            }
         }

         $contents = $dom->saveHTML(); 
         $data["skripsi"] = $contents; 
         BasicPostModel::where('id', $laravel->id)->update($data);
    }

    public function deleteIntoGoogleDrive($laravel) {
        Storage::disk('google')->delete($laravel->preview_id);
        $contents = $laravel->skripsi; 
        $dom = new DOMDocument(); 
        $dom->loadHTML($contents, 9); 
        $images = $dom->getElementsByTagName("img");  
        $result = collect($images); 
        $srcdb  = []; 
    
        if(count($result) != 0) {
            for($x=0; $x<count($result); $x++) $srcdb[] = $result[$x]->getAttribute('data-imgid'); 
            if(count($srcdb) != 0) {
               foreach($srcdb as $item) Storage::disk('google')->delete($item);
            }
        }
        BasicPostModel::destroy($laravel->id); 
    }

    
    public function debugConfig() {
        $googleConfig = [
            'clientId' => Config::get('filesystems.disks.google.clientId'),
            'clientSecret' => Config::get('filesystems.disks.google.clientSecret'),
            'refreshToken' => Config::get('filesystems.disks.google.refreshToken'),
            'folderId' => Config::get('filesystems.disks.google.folderId'),
        ];
        dd($googleConfig);
    }


    public function modifyRefreshToken(Request $request) {
        $refreshtoken = $request->refreshtoken;
        Config::set('filesystems.disks.google.refreshToken', $refreshtoken);
        $googleConfig = ['refreshToken' => Config::get('filesystems.disks.google.refreshToken'),];
        $filesystemsConfig = config_path('filesystems.php');
        $filesystemsContents = file_get_contents($filesystemsConfig);
        foreach ($googleConfig as $key => $value) {
            $pattern = "/'{$key}'\s*=>\s*.*?,/";
            $replacement = "'{$key}' => '{$value}',";
            $filesystemsContents = preg_replace($pattern, $replacement, $filesystemsContents);
        }
        file_put_contents($filesystemsConfig, $filesystemsContents);
        Artisan::call('config:clear');
        return redirect('/refreshtoken')->with('success', 'Update Token Success');
    }

    public function fngoogle() {
        $params = [
            "title" => "Setup Token", 
            "currtoken" => Config::get('filesystems.disks.google.refreshToken'),
        ];
        return view('admin.refreshtoken', $params);
    }



    public function deleteIntoFileManager($laravel) {
        if(Storage::disk('public')->exists('upload/' . $laravel->preview))  {
            Storage::disk('public')->delete('upload/' . $laravel->preview);
        }

        $contents = $laravel->skripsi; 
        $dom = new DOMDocument(); 
        $dom->loadHTML($contents, 9); 
        $images = $dom->getElementsByTagName("img");  
        $result = collect($images); 
        $srcdb  = []; 
    
        if(count($result) != 0) {
            for($x=0; $x<count($result); $x++) $srcdb[] = $result[$x]->getAttribute('data-imgid'); 
            if(count($srcdb) != 0) {
               foreach($srcdb as $item) {
                    if(Storage::disk('public')->exists('upload/' . $item))  {
                        Storage::disk('public')->delete('upload/' . $item);
                    }
               }
            }
        }
        BasicPostModel::destroy($laravel->id); 
    }

    public function saveIntoGoogleDrive($request, $data) {
        $data["user_id"] = auth()->user()->id; 

        // Image Handle 
        if($request->file('preview')) {
            $preview            = $this->generateNewName($request->file('preview')); 
            $data["preview"]    = $preview; 
            $data["preview_id"] = "debug";
            $request->file('preview')->storeAs('', $preview, 'google');
            $data["preview_id"] = $this->getIdByFileName($preview);
            Storage::disk("google")->setVisibility($data["preview_id"], 'public');
        }
        // SummerNote Handle 
        $contents = $request->skripsi; 
        $dom = new DOMDocument(); 
        $dom->loadHTML($contents, 9); 
        $images = $dom->getElementsByTagName("img"); 
        
        foreach($images as $key => $img) {
            $imageData      = $img->getAttribute('src');
            $image          = base64_decode(explode(',', explode(';', $img->getAttribute('src'))[1])[1]);
            $extension      = explode('/', mime_content_type($imageData))[1]; 
            $image_name     = $key . time() . ".$extension"; 
            $image_path     = "/storage/upload/" . $image_name; 
            file_put_contents(public_path() . $image_path, $image);

            // Read image and upload into google drive 
            $imageContents = Storage::disk('upload')->get($image_name);
            $path = Storage::disk('google')->put($image_name, $imageContents);
            $image_id = $this->getIdByFileName($image_name); 
            Storage::disk("google")->setVisibility($image_id, 'public');
            $img->removeAttribute('src'); 
            $img->setAttribute('src', "https://drive.google.com/thumbnail?id=$image_id&sz=w1000");
            $img->setAttribute('data-imgid',$image_id);
            $img->setAttribute('class', 'custom');

            // Remove the image from the local
            unlink("./storage/upload/" . $image_name);
        }
        $contents = $dom->saveHTML(); 
        $data["skripsi"] = $contents; 

        // Store in database 
        BasicPostModel::create($data);
    }

    public function saveIntoFileManager($request, $data) {
        $data["user_id"] = auth()->user()->id; 

        // Image Handle 
        if($request->file('preview')) {
            $preview = $request->file('preview'); // Get the uploaded file
            $previewName = $this->generateNewName($preview); // Generate a new name for the file
            $preview->storeAs('upload', $previewName, 'public'); // Store the file in the storage/app/public/upload directory
            $data["preview"] = $previewName; // Save the file name in the database
            $data["preview_id"] = "EMPTY";
        }

        // SummerNote Handle 
        $contents = $request->skripsi; 
        $dom = new DOMDocument(); 
        $dom->loadHTML($contents, 9); 
        $images = $dom->getElementsByTagName("img"); 
        
        foreach($images as $key => $img) {
            $imageData      = $img->getAttribute('src');
            $image          = base64_decode(explode(',', explode(';', $img->getAttribute('src'))[1])[1]);
            $extension      = explode('/', mime_content_type($imageData))[1]; 
            $image_name     = $key . time() . ".$extension"; 
            $image_path     = "/storage/upload/" . $image_name; 
            file_put_contents(public_path() . $image_path, $image);

            // Read image and upload into google drive 
            $img->removeAttribute('src'); 
            $img->setAttribute('src', $image_path);
            $img->setAttribute('class', 'custom');
            $img->setAttribute('data-imgid',$image_name);
        }
        $contents = $dom->saveHTML(); 
        $data["skripsi"] = $contents; 

        // Store in database 
        BasicPostModel::create($data);
    }

    public function updateIntoFileManager($request, $data, $laravel) {
        $data["user_id"]     = auth()->user()->id; 
        $data["preview"]     = $laravel->preview; 
        $data["preview_id"]  = $laravel->preview_id; 

        if($request->file('preview')) {
            // Delete old file 
            $oldpreview = $laravel->preview; 
            // delete the old file
            if(Storage::disk('public')->exists('upload/' . $oldpreview))  {
                Storage::disk('public')->delete('upload/' . $oldpreview);
            }

            $preview = $request->file('preview'); // Get the uploaded file
            $previewName = $this->generateNewName($preview); // Generate a new name for the file
            $preview->storeAs('upload', $previewName, 'public'); // Store the file in the storage/app/public/upload directory
            $data["preview"] = $previewName; // Save the file name in the database
            $data["preview_id"] = "EMPTY";
        }
        $this->DeleteFileManagerImageIFLocalDeleted($request, $laravel);
        $contents = $request->skripsi; 
        $dom = new DOMDocument(); 
        $dom->loadHTML($contents, 9); 
        $images = $dom->getElementsByTagName("img");  
         foreach($images as $key => $img) {
            //  kalo ada gambar baru 
            if(strpos($img->getAttribute('src'), 'data:image/') === 0) { 
                $imageData      = $img->getAttribute('src');
                $image          = base64_decode(explode(',', explode(';', $img->getAttribute('src'))[1])[1]);
                $extension      = explode('/', mime_content_type($imageData))[1]; 
                $image_name     = $key . time() . ".$extension"; 
                $image_path     = "/storage/upload/" . $image_name; 
                file_put_contents(public_path() . $image_path, $image);

                // Read image and upload into google drive 
                $img->removeAttribute('src'); 
                $img->setAttribute('src', $image_path);
                $img->setAttribute('class', 'custom');
                $img->setAttribute('data-imgid',$image_name);
            }
         }

         $contents = $dom->saveHTML(); 
         $data["skripsi"] = $contents; 
         BasicPostModel::where('id', $laravel->id)->update($data);
    }

}
