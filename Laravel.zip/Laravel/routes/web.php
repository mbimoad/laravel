<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BasicController; 
use App\Http\Controllers\BasicPostController; 
use App\Http\Controllers\BasicAuthController; 
use App\Http\Controllers\CrudPostController; 
use App\Http\Controllers\BasicCategoryController; 

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


// setup halaman not found exceptions/handler.php


// Basic 
Route::get('/', function () {
    $params = ["title" => "home"];
    return view('pages.basic', $params);
});
Route::get('/base',          [BasicController::class, 'index'])->middleware('guest');
Route::get('/base/{nama}',   [BasicController::class, 'detail'])->middleware('guest');

// Post Controller (Binding Parameter)
Route::get('/post',              [BasicPostController::class, 'index'])->middleware('guest');
Route::get('/post/{param:slug}', [BasicPostController::class, 'detail'])->middleware('guest');
Route::get('/cate/{param}',      [BasicPostController::class, 'postcate'])->middleware('guest');

Route::get('/login', [BasicAuthController::class, 'index'])->name('login')->middleware('guest'); 
Route::post('/auth', [BasicAuthController::class, 'auths']); 

// jika sudah keadaan login. atur RouteServiceProvider.php 
// /dashboard

Route::get('/register', [BasicAuthController::class, 'regist'])->middleware('guest');
Route::post('/auth2', [BasicAuthController::class, 'auth2']);
Route::post('/logout', [BasicAuthController::class, 'logout']); 


// Tambah sluggable 
// composer require cviebrock/eloquent-sluggable
// composer require cocur/slugify:4.0.0
// ubah PostModel tambahkan getRouteKeyName untuk default binding ke slug bukan ID 
Route::get('/refreshtoken',   [CrudPostController::class, 'fngoogle'])->middleware('auth')->name('mygoogle');
Route::post('/setrefreshtoken', [CrudPostController::class, 'modifyRefreshToken']);


Route::get("/dashboard",        [CrudPostController::class, 'dashboard'])->middleware('auth');
Route::get("/checkslug",        [CrudPostController::class, 'checkSlug'])->middleware('auth');
Route::resource('/admin/laravel', CrudPostController::class)->middleware('auth');


// Google drive 
// composer require google/apiclient
// composer require nao-pon/flysystem-google-drive:~1.1
// Create provider GoogleDriveServiceProvider
// edit config/filesystem.php 
// edit config/app.php 
// edit .env 
// google developer console > create project > search google drive api > enable
// create credential oauth 


// Full of SSR 
Route::get('/category', [BasicCategoryController::class, 'index'])->middleware('auth'); 
Route::get('/category/find', [BasicCategoryController::class, 'findData'])->middleware('auth'); 

Route::get('/category/create', [BasicCategoryController::class, 'create'])->middleware('auth'); 
Route::post('/category/store', [BasicCategoryController::class, 'stored']); 

Route::get('/category/update/{param}', [BasicCategoryController::class, 'update'])->middleware('auth'); 
Route::post('/category/edit/', [BasicCategoryController::class, 'edit']); 

Route::get('/category/delete/{param}', [BasicCategoryController::class, 'delete'])->middleware('auth'); 
