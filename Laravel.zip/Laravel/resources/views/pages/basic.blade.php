@extends('templates.main')
@section('contents')
    {{-- if foreach --}}
    <div class="box">
        
        @if(isset($datas1) && count($datas1) != 0) 
        <ul class="list">
            
            @foreach($datas1 as $data1)
            <li><a href="/base/{{ $data1["nama"] }}">{{ $data1["nama"] }}</a></li>
            @endforeach
        </ul>
        @endif
        {{-- if else if --}}
        @if(isset($datas2)) 
            <h1>{{ $datas2["nama"] }}</h1>
            <h3>{{ $datas2["jurusan"] }}</h3>
        @elseif(!isset($datas2))
            <span>Click To Show The Detail</span>
        @else 
            <span>Data Empty</span>
        @endif 
    </div>


    <div class="box">
        @if(isset($datas3))
        @foreach($datas3 as $d) 
            <a href="post/{{ $d->slug }}" class="card">
                <h3>{{ $d->judul   }}</h3>
                <p>{!! \Illuminate\Support\Str::limit($d->skripsi, 60, '....') !!}</p>
            </a>
        @endforeach
        @endif
    </div>
   

@endsection
