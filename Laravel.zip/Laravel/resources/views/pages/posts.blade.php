@extends('templates.main')
@section('contents')

    @if(isset($cate))
    @foreach($cate as $c)
    <a href="/cate/{{ $c->id }}">{{ $c->nama }}</a>
    @endforeach
    @endif 


    <form action="/post">
        <input type="text" name="keyword">
        <input type="number" name="tahun">
        <button type="submit">Find</button>
    </form>
    

    <div class="box">
        @if(isset($datas3) && $datas3->count() > 0)
        @foreach($datas3 as $d) 
        
            <a href="/post/{{ $d->slug }}" class="card">
                <h3>{{ $d->judul }}</h3>
                <span>{{ $d->usersRelation->name }}</span>
                <span>{{ $d->categoryRelation->nama }}</span>
                <p>{!! \Illuminate\Support\Str::limit($d->skripsi, 60, '....') !!}</p>
            </a>
        @endforeach
        @endif
    </div>

    @if(isset($datas3))
    {{-- pagination - appserviceprovider.php bootstrap --}}
    <div class="">
        {{ $datas3->links() }}
    </div>
    @endif 

    
    <div class="detail">
        @if(isset($datas4)) 
            <span class="value">{{ \Carbon\Carbon::parse($datas4->updated_at)->format('F, j Y') }}</span>
            <h1>{{ $datas4->judul }}</h1>
            {!! $datas4->skripsi !!}
            <a href="/post">Kembali</a>
        @endif   
    </div>


    <div class="categorypost">
        @if(isset($datas5))
            @foreach($datas5 as $d)
                <span class="value">{{ \Carbon\Carbon::parse($d->updated_at)->format('F, j Y') }}</span>
                <h1>{{ $d->judul }}</h1>
                {!! $d->skripsi !!}
             
            @endforeach
            <a href="/post">Kembali</a>
        @endif 
    </div>


@endsection
