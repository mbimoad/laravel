@extends('templates.main')
@section('contents')
    @if(session()->has('failed'))
        <span>{{ session('failed') }}</span>
    @endif

    @if(session()->has('success')) 
        <span>{{ session('success') }}</span>
    @endif


    @if(strtolower($title) == "login")
        <a href="/register">Register</a>
    @elseif(strtolower($title) == "register")
        <a href="/login">Login</a>
    @endif 

    <form action="{{ $formlink }}" method="POST" enctype="multipart/form-data">
        @csrf
        @error("password")
            <span>{{ $message }}</span>
        @enderror 

        @if(strtolower($title) == "register")
            <input type="text"      value="{{ @old('name') }}" name="name" placeholder="username">
        @endif 
        
        <input type="email"     value="{{ @old('email') }}" name="email" placeholder="email">
        <input type="password"  value="{{ @old('password') }}" name="password" placeholder="password">
        <button type="submit">Login</button>
    </form>
@endsection