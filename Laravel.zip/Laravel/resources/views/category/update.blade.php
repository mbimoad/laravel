@extends('templates.main')
@section('contents')
    <div class="form">
        <input type="text" class="csrf" readonly value="{{ csrf_token() }}">
        <input type="text" class="id" readonly value="{{ $category->id }}">
        <input type="text" class="oldicon" readonly value="{{ $category->icon }}">

        <input value="{{ $category->nama }}" name="nama" type="text"   class="cname" placeholder="nama">
        <input value="{{ $category->tipe }}" type="text" class="ctipe" placeholder="tipe">
        <input type="file" class="cicon">
        <button onclick="sendData(`/category/edit/`)" type="button">Kirim</button>
    </div>

    <script>
        const formdata = new FormData();
        
        const id = document.querySelector('.id');
        const oldicon = document.querySelector('.oldicon');
        const name = document.querySelector('.cname');
        const tipe = document.querySelector('.ctipe');
        const icon = document.querySelector('.cicon');
        const csrf    = document.querySelector('.csrf'); 
        const options = {
            method: 'POST', 
            body: formdata, 
            headers: {"X-CSRF-Token": csrf.value},
            credentials: "same-origin",
        }
        

        function sendData(url) {
            formdata.append("id", id.value); 
            formdata.append("oldicon", oldicon.value); 
            formdata.append("nama", name.value); 
            formdata.append("tipe", tipe.value); 
            formdata.append("icon", icon.files[0]); 
            fetch(url, options)
                .then(response => response.text())
                .then(response => console.log(response))
                // .then(response => response.json())
                // .then(response => {
                //     let status = response.status; 
                //     if(status == "OK") {
                //         alert(status);
                //     } else {
                //         alert(status);
                //     }
            // });
        }
    </script>
@endsection