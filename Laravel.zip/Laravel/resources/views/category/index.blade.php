@extends('templates.main')
@section('contents')

    <a href="/category/create">Tambah Kategori</a>

    <div class="mb-4">
        <input type="text" class="find">
        <button type="button" class="btnfind">Find Keyword</button>
    </div>

    <div class="tables"></div>
    <div class="pagination"></div>
    
    <script>
        let keyword = ""; 
        function SSRGET(url) {
            return fetch(url)
                .then(response => response.json())
        }

        async function LoadData(url) {
            let response = await SSRGET(url);
            console.log(response);
            const datas = response.categories.data; 
            const links = response.categories.links;
            // Pagination
            let buttons = links.map(item => `<button data-url="${extractPage(item.url)}" class="btnpaginate ${item.active ? 'active' : ''}">${item.label}</button>`).join('');
            document.querySelector('.pagination').innerHTML = buttons; 
            // Data
            CreateTable(datas); 
        }
        LoadData(`/category/find?page=1&keyword=` + keyword); 

        
        const find = document.querySelector('.find'); 
        const btnfind = document.querySelector('.btnfind');
        btnfind.addEventListener('click', async function() {
            keyword = find.value;
            LoadData(`/category/find?page=1&keyword=` + keyword); 
        })
 

        document.addEventListener('click', async function(e) {
            if(e.target.classList.contains('btnpaginate')) {
                let element = e.target; 
                let url = element.dataset.url; 
                if(url != "null" || url != "undefined") {
                    LoadData(`/category/find?page=${url}&keyword=` + keyword)
                }
            }

            if(e.target.classList.contains('delete')) {
                let element  = e.target; 
                let id       = element.dataset.id; 
                let response = await SSRGET(`/category/delete/${id}`)
                if(response.status == "OK") alert('Data berhasil di Hapus');
                LoadData(`/category/find?page=1&keyword=` + keyword); 
            }
        })

        function CreateTable(datas) {
            let element = `<table border="1" cellspacing="0" cellpadding="10">
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>icon</th>
                    <th>Action</th>
                </tr> `;

            element += datas.map(item => `<tr>
                    <td>${item.id}</td>
                    <td>${item.nama}</td>
                    <td>
                        <img src="storage/upload/${item.icon}"
                    </td>
                    <td>
                        <a href="/category/update/${item.id}">Update</a>
                        <button class="delete" data-id="${item.id}">Delete</a>
                    </td>
                </tr>`).join('');
            
            element += `</table>`;


            document.querySelector('.tables').innerHTML = element;            
        }

        function extractPage(url) {
            if(url) {
                url = url.split('=')[1];
                return url;
            } 
        }

    </script>

@endsection