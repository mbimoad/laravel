
<script src="{{ asset('assets/js/script.js') }}"></script>