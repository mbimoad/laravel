<header>
    {{-- Client --}}
    @guest
    <a href="/"     class="{{ strtolower($title)  == 'home' ? 'on' : '' }}">Home</a>
    <a href="/base" class="{{ strtolower($title)  == 'base' ? 'on' : '' }}">Get Data</a>
    <a href="/post" class="{{ strtolower($title)  == 'post' ? 'on' : '' }}">Post</a>
    <a href="/login" class="{{ strtolower($title) == 'login' ? 'on' : '' }}">Login</a>
    @endguest


    
    @auth
    {{-- Server --}}
    <form action="/logout" method="POST">
        @csrf
        <button type="submit">logout</button>
    </form>

    <a href="/refreshtoken" class="{{ strtolower($title) == 'setup token' ? 'on' : '' }}">refreshtoken</a>
    
    {{-- appserviceprovider.php --}}
    @can('gate_admin')
        <a href="/admin/laravel" class="{{ strtolower($title) == 'add' ? 'on' : '' }}">POST CRUD</a>
    @endcan
    
    @if(auth()->user()->name == "admin")
        <a href="/category" class="{{ strtolower($title) == 'category' ? 'on' : '' }}">KATEGORI SSR</a>
    @endif

    @endauth
</header>

