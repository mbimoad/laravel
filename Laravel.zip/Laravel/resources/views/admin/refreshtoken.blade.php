@extends('templates.main')
@section('contents')




<label for="">Current Token</label>
<input type="text" name="" value="{{ $currtoken }}">

<button class="googlebtn id btn btn-primary" type="button">Copy Oauth Client ID</button>  
<button class="googlebtn secret btn btn-primary" type="button">Copy Oauth Client Secret</button>  


<form action="/setrefreshtoken" method="POST" class="d-flex">
    @csrf 
    <input type="text" class="form-control" name="refreshtoken" placeholder="New Refresh Token">
    <button type="submit" class="sbmt ml-2 btn btn-info">Send</button>
</form>

@if(session()->has('success'))
    {{ session('success') }}
@endif



<script>
     const id = document.querySelector('.googlebtn.id'); 
    const secret = document.querySelector('.googlebtn.secret'); 
    
     id.addEventListener('click', function() {
        navigator.clipboard.writeText('400060317614-kbh3o66a5qgadhfnm6l8nq2pqb2mabsl.apps.googleusercontent.com'); 
        alert('Oauth Client ID is Copied');
    })

    secret.addEventListener('click', function() {
        navigator.clipboard.writeText('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'); 
        alert('Oauth Client Secret is Copied');
    })
</script>

@endsection