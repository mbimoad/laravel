@extends('templates.main')
@section('contents')
    {{-- * ambil apapun keyword setelahnya --}}
    <h1>{{ Request::is('admin/laravel*') ? "Halaman Admin" : "" }}</h1>

    @if(session()->has('success'))
        <div class="alert alert-warning" role="alert">
            {{ session('success') }}
        </div>
    @endif
    @if(session()->has('error'))
        <div class="alert alert-danger" role="alert">
            {{ session('error') }}
        </div>
    @endif

    <form action="/admin/laravel" method="GET">
        <input type="text" name="keyword" value="{{ old('keyword') }}">
        <select name="tahun">
            <option value="" selected>Year</option>
            <option value="2025">2025</option>
            <option value="2024">2024</option>
            <option value="2023">2023</option>
        </select>
        <button type="submit">Cari</button>
    </form>

    <a href="/admin/laravel/create">Tambah Posts</a> 
    <table border="1" cellspacing="0">
        <tr>
            <td>No</td>
            <td>Judul</td>
            <td>Cover</td>
            <td>Cover</td>
            <td>Category</td>
            <td>Action</td>
        </tr>
        {{-- @dd($posts); --}}

        @foreach($posts as $post) 
        <tr>
            <td>{{ $loop->iteration }}</td>
            <td>{{ \Illuminate\Support\Str::limit($post->judul, 10, '....') }}</td>
            <td><img src="https://drive.google.com/thumbnail?id={{ $post->preview_id }}&sz=w1000"></td>
            <td><img src="{{ asset('storage/upload/' . $post->preview)  }}" alt="Example Image"></td>
            <td>{{ $post->categoryRelation->nama }}</td>
            <td>
                <a href="/admin/laravel/{{ $post->slug }}">Detail</a>
                <a href="/admin/laravel/{{ $post->slug }}/edit">Update</a>
                <form action="/admin/laravel/{{ $post->slug }}" method="POST">
                    @method('DELETE')
                    @csrf 
                    <button type="submit">DELETE</button>
                </form>
            </td>


        </tr>
        @endforeach
    </table>

    <div class="">
        {{ $posts->links() }}
    </div>

@endsection