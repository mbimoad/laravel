@extends('templates.main')
@section('contents')
    {{-- * ambil apapun keyword setelahnya --}}
    <h1>{{ Request::is('admin/laravel*') ? "Halaman Admin" : "" }}</h1>

    @if(session()->has('success'))
        <div class="alert alert-warning" role="alert">
            {{ session('success') }}
        </div>
    @endif
    @if(session()->has('error'))
        <div class="alert alert-danger" role="alert">
            {{ session('error') }}
        </div>
    @endif

    <form action="/admin/laravel" method="GET">
        <input type="text" name="keyword" value="{{ old('keyword') }}">
        <select name="tahun">
            <option value="" selected>Year</option>
            <option value="2025">2025</option>
            <option value="2024">2024</option>
            <option value="2023">2023</option>
        </select>
        <button type="submit">Cari</button>
    </form>

    <a href="/admin/laravel/create">Tambah Posts</a> 
    <table border="1" cellspacing="0">
        <tr>
            <td>No</td>
            <td>Judul</td>
            <td>Cover</td>
            <td>Cover</td>
            <td>Category</td>
            <td>Action</td>
        </tr>
        {{-- @dd($posts); --}}

        @foreach($posts as $index => $p) 
        <tr>
            {{-- <td>{{ $loop->iteration }}</td> --}}
            <td>{{ $index + 1 + ($posts->currentPage() - 1) * $posts->perPage() }}</td>
            <td>{{ \Illuminate\Support\Str::limit($p->judul, 10, '....') }}</td>
            <td><img src="https://drive.google.com/thumbnail?id={{ $p->preview_id }}&sz=w1000"></td>
            <td><img src="{{ asset('storage/upload/' . $p->preview)  }}" alt="Example Image"></td>
            <td>{{ $p->categoryRelation->nama }}</td>
            <td>
                <a href="/admin/laravel/{{ $p->slug }}">Detail</a>
                <a href="/admin/laravel/{{ $p->slug }}/edit">Update</a>
                <form action="/admin/laravel/{{ $p->slug }}" method="POST">
                    @method('DELETE')
                    @csrf 
                    <button type="submit">DELETE</button>
                </form>
            </td>


        </tr>
        @endforeach
    </table>

    <div class="">
        {{ $posts->links() }}
    </div>

@endsection