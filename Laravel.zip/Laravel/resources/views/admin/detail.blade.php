@extends('templates.main')
@section('contents')
    <h3>How Much View this Page {{ $views }}</h3>
    <span>{{ $post->usersRelation->name }}</span>
    <h1>{{ $post->judul }}</h1>
    <p>{!! $post->skripsi !!}</p>
    <span class="value">{{ \Carbon\Carbon::parse($post->updated_at)->format('F, j Y') }}</span>
    <a href="/admin/laravel">Kembali</a>
@endsection