@extends('templates.main')
@section('contents')

    <div class="loader"></div>

    <form action="/admin/laravel" class="myform" method="POST" enctype="multipart/form-data">
        @csrf
        {{-- slug --}}
        <input type="text" name="slug" value="{{ old('slug') }}" readonly>
        {{-- judul --}}
        <input type="text" name="judul" value="{{ old('judul') }}" placeholder="judul">
        {{-- Kategori --}}
        <select name="category_id" >
            @foreach($categories as $c) 
                <option value="{{ $c->id }}">{{ $c->nama }}</option>
            @endforeach
        </select>
        {{-- Deskripsi --}}
        <textarea placeholder="deskripsi" name="deskripsi">{{ old("deskripsi") }}</textarea>
        {{-- Image Preview --}}
        <input type="file" name="preview" class="preview" onchange="shareScreen()">
        <img src="" class="showimage">

        <textarea placeholder="skripsi" id="summernote" name="skripsi">
            {{ old('skripsi') }}   
        </textarea>
        
        <button class="kirim" type="submit">Tambah (Laravel)</button>
    </form>

    @error('slug')        <span>{{ $message }}</span> @enderror
    @error('judul')       <span>{{ $message }}</span> @enderror
    @error('category_id') <span>{{ $message }}</span> @enderror
    @error('deskripsi')   <span>{{ $message }}</span> @enderror
    @error('preview')     <span>{{ $message }}</span> @enderror
    @error('skripsi')     <span>{{ $message }}</span> @enderror

    <script>
        const image = document.querySelector('.preview');
        const imgPreview = document.querySelector('.showimage');
        function shareScreen() {
            const reader = new FileReader(); 
            reader.readAsDataURL(image.files[0]);
            reader.onload = function(e) {
                imgPreview.src = e.target.result;
            }
        }

        const judul = document.querySelector('input[name="judul"]');
        const slug = document.querySelector('input[name="slug"]');

        judul.addEventListener('change', function() {
            fetch('/checkslug?param=' + judul.value)
                .then(response => response.json())
                .then(response => slug.value = response.slug)
        })


        const loader = document.querySelector(".loader");
        const kirim = document.querySelectorAll('.kirim'); 
        kirim.forEach(item => item.addEventListener('click', function() {
            loader.classList.add('active');
        }))

    </script>
@endsection