-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 21 Bulan Mei 2024 pada 06.29
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dblaravel`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `basic_category_models`
--

CREATE TABLE `basic_category_models` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipe` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `basic_category_models`
--

INSERT INTO `basic_category_models` (`id`, `nama`, `tipe`, `icon`, `created_at`, `updated_at`) VALUES
(1, 'logika fuzzy', 'desktop', NULL, '2024-05-20 14:02:07', '2024-05-20 14:02:07'),
(2, 'c45', 'website', NULL, '2024-05-20 14:02:07', '2024-05-20 14:02:07'),
(3, 'qweq', 'qweq', NULL, '2024-05-21 01:57:22', '2024-05-21 01:57:22'),
(4, 'adfaf', 'adfa', NULL, '2024-05-21 01:57:42', '2024-05-21 01:57:42'),
(5, 'adf', 'adfafd', NULL, '2024-05-21 01:58:34', '2024-05-21 01:58:34'),
(7, 'afda', 'afda', NULL, '2024-05-21 01:59:43', '2024-05-21 01:59:43'),
(8, 'adfa', 'afa', NULL, '2024-05-21 01:59:57', '2024-05-21 01:59:57'),
(12, 'adsfaf', 'adfad', NULL, '2024-05-21 02:00:42', '2024-05-21 02:00:42'),
(13, 'asdf', 'adsf', NULL, '2024-05-21 02:00:57', '2024-05-21 02:00:57'),
(14, 'afdadf', 'adfaf', NULL, '2024-05-21 02:01:13', '2024-05-21 02:01:13'),
(15, 'adfadf', 'afdf', NULL, '2024-05-21 02:01:41', '2024-05-21 02:01:41'),
(16, 'Bimo', 'Adjie', NULL, '2024-05-21 02:02:37', '2024-05-21 02:02:37'),
(18, 'af', 'df', NULL, '2024-05-21 02:03:43', '2024-05-21 02:03:43'),
(19, 'df', 'gg', NULL, '2024-05-21 02:03:50', '2024-05-21 02:03:50'),
(23, 'we', 'we', NULL, '2024-05-21 02:08:24', '2024-05-21 02:08:24'),
(28, 'wer', 'wer', NULL, '2024-05-21 02:12:51', '2024-05-21 02:12:51'),
(31, 'a', 'a', NULL, '2024-05-21 02:13:12', '2024-05-21 02:13:12'),
(33, '234', '234', NULL, '2024-05-21 02:14:38', '2024-05-21 02:14:38'),
(37, 'werz', 'werz', NULL, '2024-05-21 02:16:54', '2024-05-21 02:16:54'),
(38, 'st', 'ts', NULL, '2024-05-21 02:17:40', '2024-05-21 02:17:40'),
(42, '123', '123', NULL, '2024-05-21 02:18:10', '2024-05-21 02:18:10'),
(43, '12344', '12344', NULL, '2024-05-21 02:18:16', '2024-05-21 02:18:16'),
(44, '1234443242', '123442342', NULL, '2024-05-21 02:18:21', '2024-05-21 02:18:21'),
(45, 'sfgs', 'sgsgs', NULL, '2024-05-21 02:18:27', '2024-05-21 02:18:27');

-- --------------------------------------------------------

--
-- Struktur dari tabel `basic_models`
--

CREATE TABLE `basic_models` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `basic_post_models`
--

CREATE TABLE `basic_post_models` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `judul` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `preview` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `preview_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `skripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `basic_post_models`
--

INSERT INTO `basic_post_models` (`id`, `category_id`, `user_id`, `judul`, `slug`, `preview`, `preview_id`, `deskripsi`, `skripsi`, `published`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 'In molestiae accusantium qui repellat dolorem.', 'alias-consequuntur-quia-minima-totam-vitae-vitae-accusamus', 'marpaung.ivan', '1', 'Quibusdam earum quaerat qui omnis et. Ratione nam non voluptas ipsa. Ducimus fugiat occaecati unde et non omnis sint totam.Eaque maiores laborum numquam et vel minima. Repellat consequuntur quia provident odio vero error tempore. Veritatis at laborum dolorem vel asperiores fuga.Voluptatum alias vel ab officia laborum autem aut. Quia quaerat et voluptate voluptatum culpa qui delectus. Repudiandae quos facilis eos consequatur. Nesciunt aliquam aut occaecati molestiae.Est aliquid alias eveniet pariatur est omnis rerum animi. Adipisci pariatur velit maiores et cupiditate atque nisi. Et cupiditate delectus minima enim.Illum beatae qui perspiciatis. Maiores magni perferendis fuga tempore ea ea dolorem dolores. Aspernatur dolor velit eaque iusto vel eligendi.Tenetur perspiciatis cum ea enim ut velit ab. Velit debitis consequatur recusandae officiis aut eum. Neque eveniet atque similique corporis omnis tenetur. Quis accusantium a voluptatem accusantium odio explicabo.Est est iure in. Ut sapiente voluptate quas voluptatem ut. Odio voluptate distinctio recusandae porro quis tempora.Excepturi nemo suscipit commodi itaque. Libero et magnam illo doloribus eum. Voluptatem voluptates voluptatem ut dolorem ut et delectus. Numquam porro ab accusamus rerum assumenda id.', '<p>Odio sunt officiis consequatur cumque. Reiciendis voluptatum et atque tenetur animi reiciendis. Sit ut qui assumenda aliquid voluptas.</p><p>Mollitia aut at impedit nostrum minus. Quibusdam neque ratione suscipit. Nihil qui minus nulla saepe porro totam perspiciatis nesciunt. Et et numquam consequuntur. Ut vel quisquam voluptatem quas recusandae.</p><p>Possimus tempora impedit neque voluptatem adipisci qui dolorem officiis. Nulla blanditiis sit nulla sit. Fugiat praesentium est expedita molestiae eum perferendis.</p><p>Sequi quae et dolores non. Sequi repellendus deserunt alias mollitia. Molestias ea enim nobis vero occaecati qui. Voluptates dolorem deleniti exercitationem porro aut distinctio assumenda.</p><p>Facere autem est et ut sed. Tenetur omnis est non omnis alias. Qui sed modi eum aut quod.</p><p>Tenetur excepturi earum ratione eveniet adipisci sit. Recusandae amet et recusandae. Esse consequuntur voluptatem pariatur porro.</p><p>Temporibus excepturi voluptatem saepe. Perferendis rem ea et est eum. Corporis dignissimos expedita a in veritatis error.</p><p>Amet minima eaque qui est. Placeat voluptas ut minus consequatur possimus.</p><p>Aperiam quia ut et culpa est. Natus voluptate sint exercitationem adipisci earum. Maxime quae qui adipisci aspernatur. Accusamus neque quibusdam quisquam in beatae dignissimos.</p>', NULL, '2024-05-20 14:02:07', '2024-05-20 14:02:07'),
(2, 2, 2, 'Corporis dolor unde.', 'non-aut-repellendus-placeat-iusto-quia-aut', 'ulva.safitri', '1', 'Dolorem doloribus cupiditate reprehenderit voluptas quasi. Aut et suscipit explicabo nostrum. Qui optio nisi tempore accusamus facilis accusantium illo. Quod quia temporibus corporis mollitia.Quasi inventore dolores ducimus iusto facilis odit. Vitae itaque corporis sint illo reprehenderit qui velit veniam. Rerum quo quidem et quibusdam. Magni dolor porro omnis error.Aperiam iure consequatur omnis iste ea aliquid expedita. Sed saepe excepturi tempora. Dolores commodi ut est aut. Blanditiis ab dolore officia magnam doloribus sed.Repudiandae sint et quod illum numquam facere. Eos nemo aliquid rem qui et laborum. Eum alias cumque ut est autem debitis magnam.Architecto ducimus perferendis et aut eligendi. In nulla debitis rem molestias praesentium inventore. Sed voluptatum eius illo veniam ipsam vitae sed. Ipsa doloribus qui nisi dolorem eius.Maxime nihil placeat modi minima. Et tempora illo facere fugiat culpa iste. Aliquid aut nam enim debitis et nam ut quo. Totam quis totam et repudiandae voluptate qui deleniti.Dolores nulla omnis ea nisi laboriosam voluptas. Ullam iste soluta delectus rem minima nulla sunt dolores.Est quod quos consequatur quam. Reprehenderit qui quis quia et. Cum assumenda aut animi quis occaecati cumque minus. Deserunt et atque sequi dolorem eveniet asperiores ea veritatis.Hic et consequatur et numquam consequatur. In id provident quasi odio et. Et adipisci porro harum voluptatum quidem ad. Velit fuga error ullam praesentium blanditiis et doloremque.Hic maxime facere aut recusandae ea. Quo et porro reprehenderit excepturi dignissimos. Asperiores quia voluptatibus illum voluptatibus quia et sint. Et repellat eum ut sit aliquid sed.', '<p>Fugit quibusdam repellendus omnis error omnis. Est architecto sit voluptatem eum quam sapiente. Perspiciatis veniam quas quisquam velit optio aliquid est. Magnam dolores hic reiciendis consequatur deserunt. Natus aspernatur sit repudiandae recusandae.</p><p>Dolores in magni cupiditate molestias quasi velit. Minus quia qui quaerat fugiat. Non rerum vel sed ipsa vero.</p><p>Qui non dolorem doloribus quibusdam recusandae iste. Quis asperiores hic impedit porro et. Expedita repudiandae accusantium laborum totam a. Nulla eius voluptatem optio enim laboriosam enim reiciendis.</p><p>Magnam autem fugiat a ad. Culpa sequi rerum officia alias nulla. Voluptatem expedita nobis quidem nobis provident nostrum impedit commodi. Earum itaque optio unde quas asperiores dolorum.</p><p>Neque saepe sint eligendi laborum voluptatem. Quia aliquam delectus fuga voluptas nisi aut quaerat. Fugit excepturi dicta quis molestiae nihil. Nesciunt consequuntur ab dignissimos dolorum nostrum sapiente et aut.</p><p>Laborum sed non illo pariatur modi officiis recusandae. Delectus ea voluptatibus suscipit sapiente qui qui. Nulla aut explicabo nemo veniam quo qui.</p>', NULL, '2024-05-20 14:02:07', '2024-05-20 14:02:07'),
(3, 2, 2, 'Molestiae voluptatibus sunt quas.', 'dignissimos-possimus-mollitia-voluptas-ut-vel', 'mulyani.syahrini', '2', 'Voluptatem cupiditate dolor inventore ipsum nisi culpa. Ut nostrum odio minus ut. Laboriosam eum aut doloremque est omnis quia quod. Totam quis in exercitationem repudiandae esse. Soluta quos necessitatibus a neque repellat excepturi perferendis.Quia dolore itaque ut neque magnam sunt minus. Tempora consequatur autem quisquam ea eligendi officiis ipsum.Quia quasi unde vel in ratione ut omnis. A maxime est autem tempora quam temporibus sit. Ab omnis veniam nam est consequatur nihil aliquid illum. Perferendis voluptates reprehenderit suscipit consequuntur possimus ipsa.Eos ratione quia facilis officiis. Doloremque suscipit sed omnis natus omnis aperiam illum velit. Dicta sint consectetur nemo cumque unde cumque laudantium. Et accusamus ipsam officia eligendi dolorum quam ab.Eligendi in fuga fugit alias qui. Earum quod natus corporis consequatur recusandae qui sapiente. Quaerat harum ullam et expedita in. Blanditiis molestiae quae adipisci voluptatum ut repudiandae.', '<p>Sunt exercitationem id enim et fuga autem ipsa ipsam. Quod et quae eligendi laborum quia culpa qui. Velit omnis odit sit a sequi qui nemo blanditiis. Earum sequi voluptas autem vel.</p><p>Maiores ab voluptatem veniam autem enim et harum. Ullam voluptate similique amet dolorum modi quod voluptas. Sunt est harum earum.</p><p>Id dolores repudiandae id ut. Voluptas quo at cum quaerat. At repudiandae praesentium voluptatum consequatur ut. Tempore hic velit dicta labore maxime nesciunt saepe.</p><p>Quidem amet officiis temporibus earum repudiandae. Quia quia ut exercitationem dolores voluptas tempora. Quam nulla consequatur aut id. Tempora consequatur temporibus accusantium et at natus. Magni hic aut placeat non.</p><p>Dolores ipsa doloremque exercitationem neque. Minus unde nesciunt voluptatibus quasi corrupti rerum. Iusto veritatis saepe quas quia qui itaque dolores.</p><p>Minima quae natus non neque rem expedita. Quam dolores nam officia eius delectus. Dolorem temporibus est blanditiis non. Provident nesciunt fugit dolorum facilis nostrum odit quo.</p><p>Eos illum corrupti veritatis rerum eum. Vel repellat et laborum quam deserunt. Temporibus id sed tenetur praesentium exercitationem earum omnis.</p><p>Occaecati repellendus voluptatem quo. Occaecati doloremque doloremque molestiae illum corporis. Ea eligendi molestiae enim rerum.</p><p>Maxime consequatur est sunt aut omnis molestiae. Voluptatibus explicabo ut distinctio deleniti enim temporibus nesciunt. Harum iure doloribus quidem quae rerum. Doloremque sit qui qui.</p>', NULL, '2024-05-20 14:02:07', '2024-05-20 14:02:07'),
(4, 2, 2, 'Ut vel amet.', 'ut-cumque-amet-dolorem-esse', 'vhasanah', '2', 'Deserunt dolore quia aspernatur provident. Aut consequatur voluptatem quo aspernatur aspernatur atque. Non ab voluptate autem et nostrum maiores qui. Eius ipsam debitis velit eligendi corporis.Voluptas excepturi quo quod repellat assumenda. Velit illo consequatur deleniti consequuntur. Dolorum debitis non sit voluptatibus accusamus corrupti. Nemo consequatur dolor iusto ex autem ipsum qui dolores.Vero in labore et consectetur. Consequatur qui pariatur voluptas magnam animi ut aliquam.Repellendus eos architecto qui vero. Quae quo aliquid iusto natus eveniet quo odio. Earum excepturi aut eaque id.Aut consequatur illum officiis fuga. Sed laborum porro doloremque sed qui optio. Beatae at incidunt velit.', '<p>Impedit ut non rerum odit sit ratione ad. Est dolor quam nostrum maxime adipisci laudantium. Quae temporibus reiciendis reiciendis et. Magnam reiciendis quis id sit in asperiores tenetur.</p><p>Praesentium ut debitis assumenda veniam in repudiandae. Sint eaque ab dolores in cum molestiae. Quasi tenetur repellat laudantium enim qui est incidunt. Vel velit ab amet aut error.</p><p>Vitae temporibus rerum molestiae recusandae sit omnis. Ab quod iste est cupiditate. Explicabo excepturi aliquam est molestias eos velit. In qui ut quae ipsum quibusdam enim.</p><p>Modi aperiam commodi doloribus harum ut. Accusantium et eos dolores possimus atque. Sit mollitia modi odio exercitationem dolore et ratione.</p><p>At sequi enim aut eos qui voluptatibus voluptate. Quod dolorem praesentium explicabo qui. Consequatur molestiae et laboriosam dolores.</p><p>Quis adipisci perspiciatis enim in. Ut laborum aut deleniti quibusdam. Dolorum et pariatur consequatur.</p><p>Exercitationem odio laboriosam non ut. Quas magni sequi in nihil quasi at temporibus. Blanditiis maiores occaecati necessitatibus est possimus illo.</p><p>Tempora at adipisci ipsa rerum et magnam quia. Et placeat molestias magni omnis ea. Consequatur ea est ut id omnis pariatur dolores. Reiciendis quia ut saepe omnis eos praesentium asperiores non. Deleniti saepe error debitis ut qui est cupiditate.</p><p>Quo ut id quod maxime corporis et occaecati pariatur. Quia ut ex error quo ut.</p>', NULL, '2024-05-20 14:02:07', '2024-05-20 14:02:07'),
(5, 1, 1, 'Minus eos fugit.', 'doloribus-reiciendis-corporis-et-odio-est-beatae-perferendis-dolores', 'laila.nurdiyanti', '2', 'Ratione aperiam ut totam vero maxime. Quaerat ut velit sed porro hic sed reprehenderit. Repudiandae doloribus et dolor fugit et velit placeat. Omnis voluptatem ab aliquid at ad vel itaque animi.Eos voluptatibus deleniti tempora modi ratione omnis veritatis qui. Autem sit sed quo. Velit porro harum ab quidem nihil sit pariatur. Exercitationem maxime vero velit aspernatur perferendis dolore consequuntur.Voluptatem facere excepturi omnis debitis et nulla unde. Numquam architecto voluptates alias et dicta quas saepe. Facere repellat voluptate quis aut et in corrupti. Omnis perferendis dolor qui aut cupiditate cum veniam.Rerum est voluptatibus quod soluta harum. Sed in assumenda eum eligendi. Labore rerum at sit saepe dignissimos consequatur et. Sed qui minus dolores et est nesciunt.Delectus et aut hic laboriosam sequi officia qui. Doloribus corporis enim reiciendis. Qui veniam corrupti hic blanditiis.', '<p>Sed quo in nemo laudantium exercitationem ab eaque omnis. Quia est aut cumque voluptatum. Eveniet quidem in qui error repudiandae eveniet cupiditate.</p><p>Molestias sit ea architecto ab quo vitae perferendis. Nam laboriosam rerum facere non vero error. Eligendi consequatur sunt sunt aspernatur debitis earum qui eum.</p><p>Beatae velit exercitationem ut rerum. Voluptas recusandae voluptates minus et sint. Sed illo eum est non.</p><p>Velit dolores repellat aut ut et consequatur nostrum. Et est quae omnis est alias eos. Qui dolorum sed incidunt iste. Ut amet minus possimus.</p><p>Impedit tempore rerum quia. Quia quisquam nihil natus est dignissimos quia. Quaerat sequi dolorem id quaerat soluta. Sequi rem eum hic pariatur sed aliquid omnis.</p><p>Voluptatem non possimus et hic autem velit sit. Libero et consectetur voluptas ex nobis aut. Odit incidunt sint nesciunt corporis nemo. Est aspernatur non dicta ut necessitatibus mollitia. Nam qui doloremque amet consequatur ratione.</p>', NULL, '2024-05-20 14:02:07', '2024-05-20 14:02:07');

-- --------------------------------------------------------

--
-- Struktur dari tabel `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2024_05_17_141820_create_basic_category_models_table', 1),
(6, '2024_05_17_141852_create_basic_models_table', 1),
(7, '2024_05_17_141905_create_basic_post_models_table', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Amalia Winda Permata', 'hasanah.gara@example.net', '2024-05-20 14:02:07', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'EpRtC1Qv86', '2024-05-20 14:02:07', '2024-05-20 14:02:07'),
(2, 'Yani Usada', 'humaira10@example.com', '2024-05-20 14:02:07', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Zs62z08KIi', '2024-05-20 14:02:07', '2024-05-20 14:02:07'),
(3, 'Mahfud Adriansyah M.M.', 'apangestu@example.org', '2024-05-20 14:02:07', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'O28RKHVNsw', '2024-05-20 14:02:07', '2024-05-20 14:02:07'),
(4, 'admin', 'admin@bimo.com', NULL, '$2y$10$qvlunUqsJ3x/PbxV21JiVuHmPjXte/AamysiA0f82whMilIQYbBZW', NULL, '2024-05-20 14:04:04', '2024-05-20 14:04:04'),
(5, 'dimas', 'dimas@dsi.com', NULL, '$2y$10$Z5imI/KWiX3Q.uFEUkkN7.5UB9CUTk9OxnmGbfTpXzJTKMLjGGh4q', NULL, '2024-05-21 03:53:57', '2024-05-21 03:53:57');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `basic_category_models`
--
ALTER TABLE `basic_category_models`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `basic_category_models_nama_unique` (`nama`),
  ADD UNIQUE KEY `basic_category_models_tipe_unique` (`tipe`);

--
-- Indeks untuk tabel `basic_models`
--
ALTER TABLE `basic_models`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `basic_post_models`
--
ALTER TABLE `basic_post_models`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `basic_post_models_slug_unique` (`slug`);

--
-- Indeks untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indeks untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `basic_category_models`
--
ALTER TABLE `basic_category_models`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT untuk tabel `basic_models`
--
ALTER TABLE `basic_models`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `basic_post_models`
--
ALTER TABLE `basic_post_models`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
